Weapon Batch 001. Editable ORA sources were rebuilt from the official 05_Item_Equipable.ora template. Open each ORA in GIMP to edit the original template layers.
