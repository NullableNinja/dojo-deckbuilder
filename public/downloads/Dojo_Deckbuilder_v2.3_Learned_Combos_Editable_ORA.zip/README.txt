Dojo Deckbuilder v2.3 — Learned Combo Editable Sources

Open any .ora file in GIMP. Each card has independent template, illustration, title, flavor, stat, timing, rules, and catalog-ID layers.
